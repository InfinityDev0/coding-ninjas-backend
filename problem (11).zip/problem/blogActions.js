// Do not change the pre-written code.
// Make the necessary imports here.


export const writeBlog = (filePath, name) => {
// Write your code here.
}

export const publishBlog = (filePath) => {
// Write your code here.
}