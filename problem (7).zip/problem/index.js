// Please don't change the pre-written code
// Import the necessary modules here

const Solution = () => {
  // Write your code here
};
Solution();
module.exports = Solution;
